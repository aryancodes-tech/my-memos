chrome.runtime.onInstalled.addListener(()=>{console.log("KnowledgeOS installed")});chrome.action.onClicked.addListener(async()=>{await chrome.tabs.create({url:"chrome://newtab"})});
