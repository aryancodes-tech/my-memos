chrome.runtime.onInstalled.addListener(()=>{console.log("MyMemos installed")});chrome.action.onClicked.addListener(async()=>{await chrome.tabs.create({url:"chrome://newtab"})});
